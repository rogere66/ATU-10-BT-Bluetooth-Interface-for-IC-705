Readme file for AIROC BT Module Programmer

Copyright (C) Cypress Semiconductor, Inc. All rights reserved.

1. Software Version
====================
	Version: v2.0.23.1130

	Operating Systems:
		Windows 10

2. Files Listing
=================
	AIROC_MOD_Programmer.exe
		Application exe file.
	AIROC_MOD_Programmer.config
		Application configuration file.
	*.dll
		Application library files.
	tokens*.csv
		Sample MFi tokens file.
	Readme.txt
		This file.

3. Revision History
====================
	v2.0.23.1130
		* Change application name to "AIROC BT Module Programmer".
		* Fix a compatiable issue on erasing CYW92070xV3_EVAL.

	v1.20.22.1118 
		* Fix a bug when loading a corrupt config file.
		
	v1.19.22.513 
		* Update 20819A1 minidriver (BT-SDK 3.2, btsdk_v27) to support programming CYBT-273063-02 firmware built with btsdk_v27.

	v1.18.21.1012 10/12/2021
		* Close serial port after programming by default.

	v1.17.21.820 8/20/2021
		* Support KitProg3 USB-UART.

	v1.16.21.818 8/18/2021
		* Add CYBLE-343072-02 and CYBLE-333073-02.

	v1.15.21.428 4/28/2021
		* Support enter BDAddress manually.

	v1.14.20.1106 11/06/2020
		* Support UUID&OOB programming for BSS (Bluetooth Mesh) Provisionee 2D Barcode generation.

	v1.13.20.528 05/28/2020
		* Support CYBLE-413136-01-NoMFi token programming.
		
	v1.12.20.319 03/19/2020 
		* Add CYW20819A1ES2 support.
		
	v1.11.19.1125 11/25/2019 
		* Add CYBT-343052-02 Programming Kit support.

	v1.10.19.815 08/15/2019 
		* Add CYBT-213043-02 Programming Kit support.
		* Add CYW20719B2 support.

	v1.9.19.628 06/28/2019 
		* Add CYBT-213043-02/CYBT-243053-02 support.

	v1.8.19.617 06/17/2019 
		* Add CYBT-343052-02 support.
		* Update "hexgen2.dll" to fix VCRUNTIME140.DLL missing error.

	v1.7.19.321 03/21/2019 
		* Save token file after every programming.
		* Add "DisableCRCVerify" property.
		* Support "-CYBT013033_OTP_FIX-.hcd", "-CYBT013033_OTP_VERIFY-.hcd", "-ERASECHIP-.hex", and "-READ_SETUPINFO-.hex".

	v1.6.19.222 02/22/2019
		* Support verify OTP data from CYBT-013033-01.

	v1.6.19.124 01/02/2019
		* Show UUID/TokenB64 read from module.
		
	v1.5.19.102 01/02/2019
		* Show programming kits by default.

	v1.5.18.1226 12/26/2018
		* Add Homekit Token programming support for CYBT-343026-01.

	v1.4.18.1025 10/25/2018
		* Dedicated release to fix HP power ripple issue by writing OTP data to CYBT-013033-01.
		* Fixed GUI bug.
		* Support program without chip erasing. 

	v1.3.18.828 08/28/2018
		* Update GUI.

	v1.3.18.823 08/23/2018
		* Update GUI.
		* Improve recover process. 
		* Add BCM20737 EEPROM support.

	v1.2.18.705 07/05/2018
		* Add CYBT-423028-02 PROGRAMMING KIT REV1.0 support.
		* Add CYBT-413034-02 PROGRAMMING KIT REV1.0 support.
		* Add CYBT-483039-02 PROGRAMMING KIT REV1.0 support.
		* Add CYBT-353027-02 PROGRAMMING KIT REV1.0 support.

	v1.1.18.516 05/16/2018
		* Add CYBT-343026-01 PROGRAMMING KIT REV1.0 support.
		* Support multiple baudrates specified in .config file. 
		* Fixed a BDAddress programming bug if the first row of HEX file doesn't contain BDAddress.
		* Fixed FM25Q04 issue.

	v1.0.18.208 02/08/2018
		* The first release for CYBLE-013025-00 PROGRAMMING KIT REV1.0.

4. Known Problems
==================
  * Won't be compatible with the CyBLE device.